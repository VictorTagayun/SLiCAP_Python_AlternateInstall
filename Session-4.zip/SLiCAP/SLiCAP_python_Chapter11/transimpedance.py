#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 17 20:56:47 2021

@author: anton
"""

from SLiCAP import *
fileName = 'transimpedance'
#prj = initProject(fileName)
i1 = instruction()
i1.setCircuit(fileName + '.cir')
htmlPage('Example controller GB product requirements')
i1.setSimType('numeric')
i1.setDataType('laplace')
i1.setGainType('loopgain')
i1.setSource('I1')
i1.setDetector('V_2')
i1.setLGref('E1')
result = i1.execute()
#
gain, numerCoeffs, denomCoeffs = coeffsTransfer(result.laplace)
if len(numerCoeffs) > 1:
  text2html('Zeros found, GB determination method not valid.')
else:
  text2html('Found the nonzero DC loop gain.')
if denomCoeffs[0] == 0:
  text2html('Found poles in the origin, GB determination method not valid.')
#
LP = sp.symbols('LP')
text2html('The DC loop gain equals:')
eqn2html('L_DC', gain)
#
if len(denomCoeffs) == 1:
  text2html('No poles found, GB determination method not valid.')
LPproduct = -gain/denomCoeffs[-1]

text2html('The loop gain-poles product is found as:')
eqn2html(LP, LPproduct)
order = len(denomCoeffs) - 1
text2html('The order of the LP product is: ' + str(order))

# Find the requirement for the GB product (Bf=500kHz):
B_f = 500e3
R_o, C_d, C_c, G_B, GB_min, A_0 = sp.symbols('R_o, C_d, C_c, G_B, GB_min, A_0')

GB_minAll = sp.solve(LPproduct -(B_f*2*sp.pi)**order, G_B)[0]
text2html('The required bandwidth  = ' + str(B_f/1000) + 'kHz')
text2html('With this value, the show stopper value of the gain-bandwidth product $G_B$ is:')
GB_minNum = GB_minAll.subs([(R_o, 0), (C_d, 0), (C_c, 0)])
eqn2html('GB_min', GB_minNum)
htmlPage('Device selection and verification')
i1.defPar('A_0', '1M')
i1.defPar('C_d', '8p')
i1.defPar('C_c', '7p')
i1.defPar('R_o', 55)
i1.defPar('G_B', '16M')
i1.defPar('I_s', 1)
params2html(i1.circuit)
Bf = 1/(2*sp.pi)*LPproduct**(1/order)
BfOPA627 = sp.N(Bf.subs([(R_o, 55), (C_d, 8e-12), (C_c, 7e-12), (G_B,16e6),  (A_0, 1e6)]), 4)
text2html('The achievable low-pass cut-off frequency $f_h$ with the OPA627 in [MHz] is:')
eqn2html('f_h', BfOPA627*1e-6)

htmlPage('Bode plots')
L = i1.execute()

i1.setGainType('asymptotic')
A = i1.execute()

i1.setGainType('servo')
S = i1.execute()

i1.setGainType('direct')
D = i1.execute()

i1.setGainType('gain')
G = i1.execute()

figMag = plotSweep('TrimpMag', 'Magnitude characteristics', [L, A, S, D, G], 10e3, 10e6, 200, funcType = 'mag', show = True)
fig2html(figMag, 600)
figPhase = plotSweep('TrimpPhase', 'Phase characteristics', [L, A, S, D, G], 10e3, 10e6, 200, funcType = 'phase', show = True)
fig2html(figPhase, 600);
#
# Root-locus plot
#
tau = i1.getParValue('A_0')/2/sp.pi/i1.getParValue('G_B')
i1.defPar('tau', tau)
i1.setStepVar('A_0')
i1.setStepStart(0)
i1.setStepStop('1M')
i1.setStepMethod('lin')
i1.setStepNum(100)
i1.stepOn()
i1.setGainType('servo')
i1.setDataType('poles')
servoPoles = i1.execute()
i1.stepOff()
i1.setGainType('loopgain')
i1.setDataType('pz')
lgPZ = i1.execute()

figRL = plotPZ('TrimpRL', 'Transimpedance root locus', [servoPoles, lgPZ], xmin=-3, xmax=0, ymin=-1.5, ymax=1.5, xscale='M', yscale='M', show=True)
fig2html(figRL, 600);