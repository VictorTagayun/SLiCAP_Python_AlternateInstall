#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Thu Jul  2 14:59:59 2020

@author: anton
"""
from SLiCAP import *


fileName = 'vAmpBlackF'
prj = initProject(fileName)       # Creates the SLiCAP libraries and the
                                  # project HTML index page
i1 = instruction()                # Creates an instance of an instruction object
i1.setCircuit(fileName+'.cir')    # Checks and defines the local circuit object and
                                  # resets the index page to the project index page
i1.setSource('V1')
i1.setDetector('V_3')
i1.setSimType('symbolic')
i1.setGainType('gain')
i1.setDataType('laplace')
result = i1.execute()

htmlPage('Voltage amplifier with CCCS controller')
text2html('The gain of the system is obtained as:')
V_ell, V_s = sp.symbols('V_ell, V_s')
eqn2html(V_ell/V_s, result.laplace)