#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr 18 14:29:07 2021

@author: anton
"""

from SLiCAP import *

prj = initProject('Exercises Noise')

import noiseFigureRse
import supplyNoise
import IdriverR