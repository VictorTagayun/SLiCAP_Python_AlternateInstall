#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun May 16 13:50:34 2021

@author: anton
"""

from SLiCAP import *

fileName = 'Probe'
prj = initProject(fileName)

i1 = instruction()
makeNetlist(fileName + '.asc', fileName)

i1.setCircuit(fileName + '.cir')

i1.defPar('L_g', 0)                    # About 7n for no overshoot
CtList = [i1.getParValue('C_t')]       # Initial value of the tuning capacitor

htmlPage("Circuit data")
head2html("Circuit diagram")
img2html(fileName + '.svg', 600)
netlist2html(fileName + '.cir')
elementData2html(i1.circuit)
params2html(i1.circuit)

i1.setSource('V1')
i1.setDetector('V_scope')
i1.setSimType('numeric')
i1.setGainType('gain')

# Poles and zeros for 'untuned, 'tuned' and 'detuned' probe
htmlPage('PZ analysis')
i1.setDataType('pz')

head2html('Untuned probe')
result = i1.execute()
pz2html(result)

head2html('Tuned probe')
i1.defPar('C_t', 'R_p*C_p/R_i - C_i - C_c')
CtList.append(i1.getParValue('C_t'))
result = i1.execute()
pz2html(result)

head2html('Detuned probe')
i1.defPar('C_t', 'R_p*C_p/R_i - C_c')
CtList.append(i1.getParValue('C_t'))
result = i1.execute()
pz2html(result)

# Bode plots
htmlPage('Bode plots')
i1.setDataType('laplace')
i1.setStepVar('C_t')
i1.setStepMethod('list')
i1.setStepList(CtList)
i1.stepOn()
result = i1.execute()
figdBmag = plotSweep(fileName + '_dBmag', 'dB magnitude characteristics', result, 10, 1e9, 200, funcType='dBmag')
fig2html(figdBmag, 600)
figPhase = plotSweep(fileName + '_phase', 'Phase characteristics', result, 10, 1e9, 200, funcType='phase')
fig2html(figPhase, 600)

# Step responses
htmlPage('Step responses')
i1.setDataType('step')
result = i1.execute()
figStepShort = plotSweep(fileName + '_StepShort', 'Step responses', result, 0, 10, 200, sweepScale='n')
fig2html(figStepShort, 600)
figStepLong = plotSweep(fileName + '_StepLong', 'Step responses', result, 0, 0.5, 200, sweepScale='m')
fig2html(figStepLong, 600)

# Effect of ground wire, stepping it from 1nH to 100nH
htmlPage('Ground wire')
i1.defPar('C_t', CtList[1]) # Use value for compensated probe
i1.setStepVar('L_g')
i1.setStepStart('1n')
i1.setStepStop('100n')
i1.setStepNum(100)
i1.setStepMethod('lin')

# Plot the poles as a function of the ground wire inductance
i1.setDataType('poles')
result = i1.execute()
polesTraces = plotPZ('PZ_groundWire', 'Effects of ground wire', result)
fig2html(polesTraces, 600)
polesTracesZoom = plotPZ('PZ_groundWireZoom', 'Effects of ground wire (detailed)', result, xmin=-800e6, xmax=0, ymin=-400e6, ymax=400e6)
fig2html(polesTracesZoom, 600)

# Plot the step responses for some selected values
i1.setStepList([0, 7e-9, 11e-9, 100e-9])
i1.setStepMethod('list')
i1.setDataType('step')
result = i1.execute()
figStepWire = plotSweep(fileName + '_StepGroundWire', 'Effects of ground wire', result, 0, 20, 200, sweepScale='n')
fig2html(figStepWire, 600)

# Plot the Bode plots for some selected values
i1.setDataType('laplace')
result = i1.execute()
figMagWire = plotSweep(fileName + '_StepGroundWire', 'Effects of ground wire', result, 10, 1000, 200, sweepScale='M', funcType='dBmag', show=True)
fig2html(figMagWire, 600)
figPhaseWire = plotSweep(fileName + '_StepGroundWire', 'Effects of ground wire', result, 10, 1000, 200, sweepScale='M', funcType='phase', show=True)
fig2html(figPhaseWire, 600)