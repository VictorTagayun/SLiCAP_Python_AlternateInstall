#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun May 16 22:07:00 2021

@author: anton
"""

from SLiCAP import initProject

prj = initProject('Motor drivers')
import MotorDriver1
import MotorDriver2