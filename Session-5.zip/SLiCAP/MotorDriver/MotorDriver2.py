#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun May 16 20:51:51 2021

@author: anton
"""

from SLiCAP import *

fileName = 'SecondOrderDriver'
#prj = initProject(fileName)

i1 = instruction()
makeNetlist(fileName + '.asc', fileName)
i1.setCircuit(fileName + '.cir')
i1.defPar('R_z', 'L_m/(R_m + R_s)/C_i1')

htmlPage('Circuit data')
head2html('Circuit diagram')
img2html(fileName + '.svg', 800)
netlist2html(fileName + '.cir')
elementData2html(i1.circuit)
params2html(i1.circuit)

i1.setSimType('numeric')

htmlPage('Bandwidth calculated from the gain')
i1.setGainType('gain')
i1.setDataType('laplace')
i1.setSource('V1')
i1.setDetector('I_L1')
result = i1.execute()
idealGain = result.laplace
text2html('The gain $G$ is found as:')
eqn2html('G', idealGain)

transferCoeffs = coeffsTransfer(result.laplace)

text2html('The bandwidth can be calculated from the coefficient of the highest power of $s$ of the denominator:')
gain, numerCoeffs, denomCoeffs = transferCoeffs
coeffsTransfer2html(transferCoeffs)
order = len(denomCoeffs) - 1
if order == 1:
    B_gain = sp.Abs(1/2/sp.pi/denomCoeffs[-1])
else:
    B_gain = sp.Abs(1/2/sp.pi/(denomCoeffs[-1])**(1/order))
   
head2html('Bandwidth')
text2html('In this way we obtain:')
eqn2html('B_gain', B_gain, units= 'Hz')

htmlPage('Bandwidth calculated from the loop gain')
i1.setLGref('E1')
i1.setGainType('loopgain')
result = i1.execute()
text2html('The loop gain is found as:')
loopGain = result.laplace
eqn2html('L', loopGain)
text2html('The bandwidth can be calculated from the loop gain-poles product:')
transferCoeffs = coeffsTransfer(result.laplace)
L_0, numerCoeffs, denomCoeffs = transferCoeffs
coeffsTransfer2html(transferCoeffs)
order = len(denomCoeffs) - 1
if order == 1:
    B_LP = sp.Abs(1/2/sp.pi/denomCoeffs[-1]*L_0)
else:
    B_LP = sp.Abs(1/2/sp.pi/(denomCoeffs[-1]*L_0)**(1/order))
   
head2html('Bandwidth')
text2html('In this way we obtain:')
eqn2html('B_LP', B_gain, units= 'Hz')